### Répertoire public/assets/

Ce répertoire contient les fichiers accessibles par le navigateur, soit principalement vos fichiers .css, .js et images. 

Le nom du dossier ne doit pas être modifié, mais vous êtes libre d'y créer autant de sous-dossiers que nécessaire. 