### Répertoire app/Controller

Ce répertoire contient vos différents contrôleurs. Vous pouvez y créer des sous-dossiers sans problème, du moment que les espaces de noms de vos contrôleurs collent à la structure de ces dossiers. 

Tous vos contrôleurs devraient hériter de \W\Controller\Controller, le contrôleur de base du framework W. 