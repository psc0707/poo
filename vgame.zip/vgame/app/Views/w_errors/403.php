<?php $this->layout('layout', ['title' => 'Nothing to see here']) ?>

<?php $this->start('main_content'); ?>
<h1>403. Nothing to see here.</h1>
<?php $this->stop('main_content'); ?>
