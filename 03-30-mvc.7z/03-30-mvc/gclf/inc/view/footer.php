	<footer>
		<p align="center">&copy; Tous droits réservés - NumericALL <?php echo date('Y'); ?></p>
	</footer>
</body>
</html>