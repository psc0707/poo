<?php

/*
EXERCICE 1
----------
appliquer le pattern MVC au fichier details.php

EXERCICE++
----------
- appliquer le pattern MVC au fichier index.php

EXERCICE-extra
--------------
- dans la classe Film :
	* créer une méthode statique retournant l'objet à partir d'un ID
- dans la classe Categorie :
	* créer une méthode statique retournant l'objet à partir d'un ID
*/