<?php

/*
EXERCICE 2
----------
- appliquer les modifications pour le controleur frontal index.php pour "details"

EXERCICE-extra
--------------
- appliquer les modifications pour le controleur frontal index.php pour tout le projet (home inclus)
*/