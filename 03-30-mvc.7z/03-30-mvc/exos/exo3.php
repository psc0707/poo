<?php

/*
EXERCICE 3
----------
- sans modifier le .htaccess, faire en sorte que
	/gclf/catalogue/film/2 pointe sur la page "détails" avec l'ID 2
	/gclf/catalogue/film/3 pointe sur la page "détails" avec l'ID 3
	etc.
  
EXERCICE++
----------
- sans modifier le .htaccess, faire en sorte que
	* /catalogue/2 pointe sur la page "catalogue" à la page n°2
	* /catalogue/3 pointe sur la page "catalogue" à la page n°3
	etc.

EXERCICE-extra
--------------
- de même pour les autres pages de GCLF
*/