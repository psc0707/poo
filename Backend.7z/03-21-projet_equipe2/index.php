<pre><?php

// HTTP request to API OMDbAPI

$json = file_get_contents('http://www.omdbapi.com/?t=rogue+one');
echo $json.'<br>';

// Get it as object
$object = json_decode($json);
var_dump($object);
// J'affiche le genre
echo 'Genre: '.$object->Genre.'<br>';

// Get it as array
$array = json_decode($json, true);
var_dump($array);
// J'affiche le genre
echo 'Genre: '.$array['Genre'].'<br>';

?></pre>