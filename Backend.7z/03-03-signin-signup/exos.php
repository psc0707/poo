<?php

/*
EXERCICE 1
------------------------
- ajouter une page de sign up dans le projet TOTO (+lien navbar)
- récupérer la page d'inscription
- créer manuellement, dans la database du projet TOTO, une table user, similaire à celle importée avant
- modifier le POST d'inscription pour vérifier la validité de l'adresse email
- modifier le POST d'inscription pour qu'un user soit unique (basé sur email)
- ajouter la contrainte d'unicité de l'email dans la table user
- mettre la vérification (SQL) d'un user dans une fonction

EXERCICE++
------------------------
- modifier le POST d'inscription pour vérifier que le password soit assez complexe : taille >= 8

EXERCICE-extra
------------------------
- modifier le POST d'inscription pour vérifier que le password soit complexe :
	taille >= 8, au moins un chiffre et une majuscule (utiliser une expression régulière)
*/


/*
EXERCICE 2
----------------------
- à partir du formulaire fourni, et dans un nouveau fichier PHP, ajouter une ligne dans le tableau $_SESSION avec clé et valeur
- afficher le contenu du tableau $_SESSION (sans print_r, ni var_dump)
- afficher l'identifiant de session (voir la doc)

EXERCICE++
----------------------
- permettre à l'utilisateur de supprimer une ligne du tableau $_SESSION (qu'il choisit, passer la clé en GET par exemple)

EXERCICE-extra
----------------------
- pour chaque variable en session, créer automatiquement sa variable globale
	=> $_SESSION['toto'] = 45;
		=> donne l'équivalent de : $toto = 45;
*/
?>
<form action="" method="post">
	<fieldset>
		<legend>Play with PHP Session</legend>
		<input type="text" name="key" value="" placeholder="Clé tableau session" /><br />
		<input type="text" name="value" value="" placeholder="Valeur tableau session" /><br />
		<input type="submit" value="Add to $_SESSION" />
	</fieldset>
</form>


<?php
/*
EXERCICE 3 - Projet Toto
-------------------------
- modifier le script de sign in pour mettre en session l'id du user
- modifier le script de sign up pour mettre en session l'id du user
- pour tester, afficher l'id du user dans la navbar

EXERCICE 3++
----------------------
- mettre en session l'adresse IP du user connecté, et vérifier à chaque page que l'adresse de l'utilisateur courant est la même

EXERCICE-extra
----------------------
- passer dans une fonction la vérification email password
- ne pas afficher le form inscription (ni son lien) si déjà connecté
- ne pas afficher le form login (ni son lien) si déjà connecté
- ajouter un bouton "deconnexion" si déjà connecté, qui va déconnecter (supprimer les variables en session)
- mettre en session l'adresse IP du user connecté
*/
