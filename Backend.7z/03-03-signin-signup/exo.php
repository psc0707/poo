<?php
// TOUJOURS au début !!!!!
session_start();

// - à partir du formulaire fourni, et dans un nouveau fichier PHP, ajouter une ligne dans le tableau $_SESSION avec clé et valeur
// si formulaire soumis
if (!empty($_POST)) {
	// Je récupère les données
	$key = isset($_POST['key']) ? trim($_POST['key']) : '';
	$value = isset($_POST['value']) ? trim($_POST['value']) : '';

	if ($key != '' && $value != '') {
		// J'ajoute au tableau de session
		$_SESSION[$key] = $value;
	}
}

// - permettre à l'utilisateur de supprimer une ligne du tableau $_SESSION (qu'il choisit, passer la clé en GET par exemple)
// Si suppression
if (isset($_GET['delete'])) {
	$keyToDelete = $_GET['delete'];
	unset($_SESSION[$keyToDelete]);
	// Redirection vers la meme page (mais sans les paramètres d'URL/URI)
	header('Location: exo.php');
	exit;
}

?>
<html>
<head>
	<title>User sign up</title>
	<meta charset="utf-8">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-2 col-sm-2 col-xs-0"></div>
			<div class="col-md-8 col-sm-8 col-xs-12">
				<div class="page-header">
		  			<h1>Play with PHP Session</h1>
				</div>

				<form action="" method="post">
					<fieldset>
						<input type="text" name="key" value="" placeholder="Clé tableau session" class="form-control" /><br />
						<input type="text" name="value" value="" placeholder="Valeur tableau session" class="form-control" /><br />
						<input type="submit" class="btn btn-success btn-block" value="Add to $_SESSION" />
					</fieldset>
				</form>
			</div>
			<div class="col-md-2 col-sm-2 col-xs-0"></div>
		</div>
		<!--
		- afficher le contenu du tableau $_SESSION (sans print_r, ni var_dump)
		-->
		<?php if (sizeof($_SESSION) > 0) : ?>
		<div class="row">
			<div class="col-md-2 col-sm-2 col-xs-0"></div>
			<div class="col-md-8 col-sm-8 col-xs-12">
				<div class="page-header">
		  			<h1>Variables in Session</h1>
				</div>

				<table class="table">
				<thead>
				<tr>
					<td>Key</td>
					<td>Value</td>
					<td>&nbsp;</td>
				</tr>
				</thead>
				<tbody>
				<?php foreach ($_SESSION as $sessionKey=>$sessionValue) : ?>
				<tr>
					<td><?= $sessionKey ?></td>
					<td><?= $sessionValue ?></td>
					<!--
					- permettre à l'utilisateur de supprimer une ligne du tableau $_SESSION (qu'il choisit, passer la clé en GET par exemple)
					-->
					<td><a href="?delete=<?= $sessionKey ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
				</table>
			</div>
			<div class="col-md-2 col-sm-2 col-xs-0"></div>
		</div>
		<?php endif; ?>

	</div>

</body>
</html>