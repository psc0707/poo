<pre><?php

// A mettre ABSOLUMENT !!!!!
// ET AU DEBUT DU FICHIER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
session_start();

// Debug
print_r($_SESSION);

// Je supprime une donnée en session
unset($_SESSION['toto']);

// si je veux tout supprimer
if (isset($_GET['all']) && $_GET['all'] == 1) {
	echo 'session supprimée';
	//session_destroy();
	session_unset();
	session_regenerate_id();
}

?>
</pre>
<br>