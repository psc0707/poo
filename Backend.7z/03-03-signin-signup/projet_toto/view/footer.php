
		<br><br>
		<div class="panel panel-default">
  			<div class="panel-body text-center">
  				proGweb SARL &copy; <?= date('Y') ?> - Tous droits réservés<br>
  				<a href="<?= $socialLinks->facebook->shareUrl ?>">Facebook</a>&nbsp;|
  				<a href="<?= $socialLinks->twitter->shareUrl ?>">Twitter</a>&nbsp;|
  				<a href="<?= $socialLinks->linkedin->shareUrl ?>">LinkedIn</a>
  			</div>
  		</div>
	</div>

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>