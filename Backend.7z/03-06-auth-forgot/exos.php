<?php

/*
EXERCICE 1
- écrire un fichier editeur.php qui nécessite
	un utilisateur authentifié par les roles "admin" ou "editeur"
EXERCICE++
- si l'utilisateur n'est pas autorisé, renvoyer une "page 403"
*/