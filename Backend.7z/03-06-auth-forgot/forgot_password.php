<?php

// Inclusion de config.php
require dirname(__FILE__).'/inc/config.php';

// Formulaire soumis
if (!empty($_POST)) {
	// Debug
	print_r($_POST);

	// Je récupère les données
	$emailToto = isset($_POST['emailToto']) ? trim($_POST['emailToto']) : '';
	// tableau d'erreurs
	$errorList = array();

	// Je valide les données
	if (empty($emailToto)) {
		$errorList[] = 'Email vide';
	}
	// TODO valider les données

	// Aucune erreur
	if (empty($errorList)) {
		$sql = '
			SELECT usr_id, usr_email, usr_password, usr_role
			FROM user
			WHERE usr_email = :email
		';
		$sth = $pdo->prepare($sql);
		$sth->bindValue(':email', $emailToto);

		// J'exécute
		if ($sth->execute() === false) {
			print_r($sth->errorInfo());
		}
		else {
			// Si au moins 1 résultat => je teste le password
			if ($sth->rowCount() > 0) {
				// Je récupère la 1ère ligne de résultat
				$row = $sth->fetch(PDO::FETCH_ASSOC);

				// TODO générer un token
				$token = '';

				// TODO UPDATE sur user => field usr_token

				// Je crée le link
				$link = 'http://localhost/php12/reset_password.php?token='.$token

				// On envoyer l'email
				$emailContent = 'Yo tu as voulu changer ton mot de passe <a href="'.$link.'">cliques ici</a>';

				// TODO déclarer la fonction sendEmail dans functions.php
				sendEmail($row['usr_email'], 'Mot de passe oublié', nl2br($emailContent));
			}
		}
	}
}


// A la fin (TOUJOURS) les vues
include dirname(__FILE__).'/view/forgot_password.phtml';