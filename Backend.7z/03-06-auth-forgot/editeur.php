<?php

// Inclusion de config.php
require dirname(__FILE__).'/inc/config.php';

print_r($_SESSION);

// si non authorisé
if (!isset($_SESSION['user_role'])) {
	header("HTTP/1.1 401 Unauthorized");
	die('Veuillez vous connecter');
	// TODO rediriger sur la page signin
}
else if ($_SESSION['user_role'] != 'admin' && $_SESSION['user_role'] != 'editor') {
	header('HTTP/1.1 403 Forbidden');
	die('Vous n\'avez les droits');
}

// Comment écrire une conditon complexe ?
// Règle simple
// $_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'editor'
// condition, on inverse TOUT
// $_SESSION['user_role'] != 'admin' && $_SESSION['user_role'] != 'editor'
// Ou alors on est faignant
// !($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'editor')

?>
OK !!!

