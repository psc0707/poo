<?php

session_start();

// Le fichier de config contient toutes les valeurs de configuration qui change entre les différents serveurs (dév et prod par exemple)
$config = array(
	'DB_username' => 'root',
	'DB_password' => 'totowf3',
	'DB_database' => 'auth',
	'DB_host' => 'localhost',
);

// J'inclus la connexion à la DB
require_once dirname(__FILE__).'/db.php';
// J'inclus le fichier de fonctions
require_once dirname(__FILE__).'/functions.php';