<?php

// Inclusion de config.php
require dirname(__FILE__).'/inc/config.php';

print_r($_SESSION);

if ($_SESSION['user_role'] != 'admin') {
	echo 'Forbidden';
	exit;
}

?>
Tu peux accéder à cette page, car tu es ADMIN !!!!<br>