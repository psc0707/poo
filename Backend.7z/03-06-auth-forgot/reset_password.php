<?php

// Inclusion de config.php
require dirname(__FILE__).'/inc/config.php';

// TODO récupérer le token de l'URL/URI

//  TODO récupérer l'id user correspondant au toekn

// Afficher le formulaire uniquement si token valide


// Formulaire soumis
if (!empty($_POST)) {
	// Debug
	print_r($_POST);

	// Je récupère les données
	$passwordToto1 = isset($_POST['passwordToto1']) ? trim($_POST['passwordToto1']) : '';
	$passwordToto2 = isset($_POST['passwordToto2']) ? trim($_POST['passwordToto2']) : '';
	// tableau d'erreurs
	$errorList = array();

	// TODO valider les données

	// Si les password sont différents
	if ($passwordToto1 != $passwordToto2) {
		$errorList[] = 'Les 2 mots de passe sont différents';
	}

	// Aucune erreur
	if (empty($errorList)) {
		// TODO update du password et du token
	}
}


// A la fin (TOUJOURS) les vues
include dirname(__FILE__).'/view/reset_password.phtml';