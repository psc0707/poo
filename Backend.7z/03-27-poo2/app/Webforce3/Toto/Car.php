<?php

// Je place cette classe dans le namespace \app\Webforce3\Toto
namespace app\Webforce3\Toto;
// Le namespace correspond aux fichiers physiques pour l'autoload

/**
 * Description of Car
 *
 * @author Etudiant
 */
class Car {
	/** @var string */
	protected $brand;
	/** @var string */
	protected $model;
	/** @var string */
	protected $vin;
	/** @var string */
	protected $licencePlate;
    
    public function __construct($brandToto, $modelToto, $vinToto, $licencePlateToto) {
        $this->brand = $brandToto;
        $this->model = $modelToto;
        $this->vin = $vinToto;
        $this->licencePlate = $licencePlateToto;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getModel() {
        return $this->model;
    }

    public function getVin() {
        return $this->vin;
    }

    public function getLicencePlate() {
        return $this->licencePlate;
    }

    public function setBrand($brand) {
        $this->brand = $brand;
    }

    public function setModel($model) {
        $this->model = $model;
    }

    public function setVin($vin) {
        $this->vin = $vin;
    }

    public function setLicencePlate($licencePlate) {
        $this->licencePlate = $licencePlate;
    }
    
    public function displayInfos() {
        echo 'Brand='.$this->brand.'<br>';
        echo 'Model='.$this->model.'<br>';
        echo 'VIN='.$this->vin.'<br>';
        echo 'LicensePlate='.$this->licencePlate.'<br>';
    }
}
