<pre><?php

// Je mets en place le chargement automatique des classes selon le PSR-4
spl_autoload_register();

// J'importe une classe (pas besoin de require)
use app\Webforce3\Toto\Titi\Car2;

// J'instancie un objet (pas besoin de require)
$audiA1 = new app\Webforce3\Toto\Car('Audi', 'A1', 'FDSTSRTEDHEQG4547D', 'LU 8787');
print_r($audiA1);

// J'instancie un objet (pas besoin de require)
$audiA3 = new Car2('Audi', 'A3');
print_r($audiA3);

// DEBUG
$files = get_included_files();
print_r($files);

?></pre>