<pre><?php

// J'inclus mes classes
require dirname(__FILE__).'/inc/Vehicle.php'; // les parents d'abord
require dirname(__FILE__).'/inc/Car.php';
require dirname(__FILE__).'/inc/Webforce3/Car.php';
require dirname(__FILE__).'/inc/Webforce3/Car2.php';
require dirname(__FILE__).'/inc/Moteur.php';
require dirname(__FILE__).'/inc/Bike.php';
require dirname(__FILE__).'/inc/Moto.php';

use \WebforceToto\Tata\Titi\Tutu\Car2; // import
use \WebforceToto\Tata\Titi\Tutu\Car2 as CarPatrice; // import & alias

// J'instancie ma voiture
$f40 = new Car(
	new Moteur(
        'Ferrari',
        'F120D',
        'Essence',
        352,
        8,
        2936
    ),
	'SFGh2465465DSFGHD',
	'DF 7896',
	'rouge',
	'Ferrari',
	'F40',
	2
);
print_r($f40);
$f40->paintInBlue();
$f40->setModel('GT40');
print_r($f40);

// Exo1
$velo = new Bike(
    'bleu',
    'Giant',    
    'G458',
    3,
    7
);
print_r($velo);
$velo->setNbSpeeds(4);
print_r($velo);
echo 'Steering : '.$velo->getSteeringName().'<br>';

// Exo1++
$sv650n = new Moto(
        'bleu',
        'Suzuki',
        'SV650n',
        new Moteur(
                'Suzuki',
                'BiCylindre',
                'Essence',
                50,
                2,
                650
            ),
        2,
        false,
        'roadster'
    );
print_r($sv650n);

// NAMESPACE

$fiesta = new \WebforceToto\Car('Ford', 'Fiesta', 'SFGFSg54587sf', 'LU 8977');
print_r($fiesta);
$fiesta->displayInfos(); // OK
//$f40->displayInfos(); // Method does not exist

// \WebforceToto\Car => FQCN
// Fully Qualified Class Name

// 3 façon pour instancier la même classe

$voiture = new Car2('Audi', 'A1');
print_r($voiture);

$voiture2 = new CarPatrice('Audi', 'A3');
print_r($voiture2);

// with Fully Qualified Class Name
$voitureFQCN = new \WebforceToto\Tata\Titi\Tutu\Car2('Audi', 'A4');
print_r($voitureFQCN);

?></pre>