<?php

/*
EXERCICE 4
-----------
- déplacer et renommer les fichiers pour qu'ils correspondent au PSR-4
- retirer les require et utiliser spl_autoload_register() dans le script d'appel

EXERCICE-extra
---------------
- lire et comprendre le standard PSR-0 et les différences avec PSR-4
*/