<?php

/*
EXERCICE 3
-----------
- déclarer les classes Game, VideoGame, etc. dans le namespace "Core\WebForce3"
- écrire un alias de \Core\WebForce3\VideoGame en JeuVideo et modifier l'appel en conséquence
*/