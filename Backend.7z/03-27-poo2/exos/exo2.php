<?php
/*
EXERCICE 2
-----------
- écrire la classe Game dont la classe VideoGame (à partir de VideoGameBis d'hier) va hériter avec les propriétés correspondantes (par ex. date de sortie, titre, editeur)
- modifier la classe VideoGame (copier celle d'hier) en héritant de la classe Game (penser à supprimer les propriétés redondantes car héritées)
- écrire un script qui créé 1 instance de cet objet
	(par ex. NBA 2K16)
	* puis qui affiche le titre
	* puis qui modifie la valeur de cette propriété
	* puis qui affiche la valeur de cette propriété

EXERCICE++
-----------
- déplacer les méthodes qu'il faut dans la classe parent et surcharger si besoin
- écrire la classe CardGame qui hérite de la classe Game avec les propriétés qui vous semble correspondre

EXERCICE-extra
-----------
- écrire un script qui créé 2 instances de cet objet CardGame
	(par ex. Magic, Pokémon)
	* puis qui affiche le titre
	* puis qui modifie la valeur de cette propriété
	* puis qui affiche la valeur de cette propriété
- écrire plusieurs classes "enfant" de Jeu, à partir des données fournies par wikipédia : https://fr.wikipedia.org/wiki/Jeu#Types_de_jeux
*/