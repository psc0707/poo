<?php

/*
EXERCICE 1
-----------
- écrire la classe Velo qui hérite de Vehicule
- utiliser le constructeur du parent pour définir
	les propriétés héritées du parent

EXERCICE++
-----------
- écrire la classe Moto qui hérite de Vehicule

EXERCICE-extra
-----------
- écrire la classe Trottinette qui hérite de Vehicule
- écrire la classe Charette qui hérite de Vehicule
*/