<?php

/**
 * Description of Moto
 *
 * @author Etudiant
 */
class Moto extends Vehicle {
    /** @var Moteur */
    protected $moteur;
    /** @var int */
    protected $nbSeats;
    /** @var bool */
    protected $isWithSidecar;
    /** @var string */
    protected $type;
    
    public function __construct($color='', $brand='', $model='', $moteur=null, $nbSeats=1, $isWithSidecar=false, $type='') {
        // Appel constructeur parent
        parent::__construct($color, $brand, $model);
        
        // + affectations propriétés enfants
        $this->moteur = $moteur;
        $this->nbSeats = $nbSeats;
        $this->isWithSidecar = $isWithSidecar;
        $this->type = $type;
        
        // + affectations propriétés parents en dur (car ne change pas d'une moto à une autre)
        $this->nbWheels = 2;
        $this->power = 'moteur';
        $this->steering = Vehicle::STEERING_HANDLE_BAR;
    }

    /**
     * 
     * @return Moteur
     */
    public function getMoteur() {
        return $this->moteur;
    }

    /**
     * 
     * @return int
     */
    public function getNbSeats() {
        return $this->nbSeats;
    }

    /**
     * 
     * @return bool
     */
    public function getIsWithSidecar() {
        return $this->isWithSidecar;
    }

    /**
     * 
     * @return string
     */
    public function getType() {
        return $this->type;
    }

    /**
     * 
     * @param Moteur $moteur
     */
    public function setMoteur($moteur) {
        $this->moteur = $moteur;
    }

    /**
     * 
     * @param int $nbSeats
     */
    public function setNbSeats($nbSeats) {
        $this->nbSeats = $nbSeats;
    }

    /**
     * 
     * @param bool $isWithSidecar
     */
    public function setIsWithSidecar($isWithSidecar) {
        $this->isWithSidecar = $isWithSidecar;
    }

    /**
     * 
     * @param string $type
     */
    public function setType($type) {
        $this->type = $type;
    }
}
