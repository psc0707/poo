<?php

// Je place cette classe dans le namespace \WebforceToto\Tata\Titi\Tutu
namespace WebforceToto\Tata\Titi\Tutu;

/**
 * Description of Car
 *
 * @author Etudiant
 */
class Car2 {
	/** @var string */
	protected $brand;
	/** @var string */
	protected $model;
    
    public function __construct($brandToto, $modelToto) {
        $this->brand = $brandToto;
        $this->model = $modelToto;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getModel() {
        return $this->model;
    }

    public function setBrand($brand) {
        $this->brand = $brand;
    }

    public function setModel($model) {
        $this->model = $model;
    }
    
    public function displayInfos2() {
        echo 'Brand='.$this->brand.'<br>';
        echo 'Model='.$this->model.'<br>';
        echo 'VIN='.$this->vin.'<br>';
        echo 'LicensePlate='.$this->licencePlate.'<br>';
    }
}
