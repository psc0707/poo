<pre><?php

// J'inclus toutes mes classes (exo2)
/*require dirname(__FILE__).'/inc/Game.php';
require dirname(__FILE__).'/inc/VideoGame.php';
require dirname(__FILE__).'/inc/CardGame.php';*/
// EXO4
spl_autoload_register();

// EXO3
use Core\Webforce3\CardGame;

//EXO3 - écrire un alias de \Core\WebForce3\VideoGame en JeuVideo et modifier l'appel en conséquence
use Core\Webforce3\VideoGame as JeuVideo;

// J'instancie la classe VideoGame
$dayOfTentacle = new \Core\Webforce3\VideoGame(
	'Day of Tentacule',
	'1993-06-25',
	'LucasArts',
	'Adventure',
	JeuVideo::CONSOLE_PC
);
echo 'Mon jeu vidéo est : '.$dayOfTentacle->getTitle().'<br>';
// Correction du titre
$dayOfTentacle->setTitle('Day of tentacle');
echo 'Mon jeu vidéo est désormais : '.$dayOfTentacle->getTitle().'<br>';

// J'instancie la classe CardGame
$texasHoldEm = new CardGame(
    'Texas Hold\'em Poker',
    '1900-01-01',
    'Texans',
    52
);
print_r($texasHoldEm);
?></pre>