<?php

namespace Core\Webforce3;

/**
 * Description of Game
 *
 * @author Etudiant
 */
abstract class Game {
	/** @var string */
	protected $title;
	/** @var string */
	protected $releaseDate;
	/** @var string */
	protected $editor;
    
    public function __construct($title='', $releaseDate='', $editor='') {
        $this->title = $title;
        $this->releaseDate = $releaseDate;
        $this->editor = $editor;
    }

	// Fonction permettant de savoir si un jeu vidéo est sorti ou non
	public function isReleased() {
		if (strtotime($this->releaseDate) <= time()) {
			return true;
		}
		return false;
	}

	// Fonction permettant de sortir un jeuvideo
	public function release() {
		$this->releaseDate = date('Y-m-d');
	}

    public function getTitle() {
        return $this->title;
    }

    public function getReleaseDate() {
        return $this->releaseDate;
    }

    public function getEditor() {
        return $this->editor;
    }

    public function setTitle($title) {
        $this->title = $title;
    }

    public function setReleaseDate($releaseDate) {
        $this->releaseDate = $releaseDate;
    }

    public function setEditor($editor) {
        $this->editor = $editor;
    }

}
