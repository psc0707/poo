<?php

namespace Core\Webforce3;

/**
 * Description of CardGame
 *
 * @author Etudiant
 */
class CardGame extends Game {
    /** @var int */
    protected $nbCards;
    
    public function __construct($title='', $releaseDate='', $editor='', $nbCards=0) {
        // J'appelle le constructeur du parent
        parent::__construct($title, $releaseDate, $editor);
        
        // Je définis la valeur pour la propriété de cette classe
        $this->nbCards = $nbCards;
    }

    public function getNbCards() {
        return $this->nbCards;
    }

    public function setNbCards($nbCards) {
        $this->nbCards = $nbCards;
    }
}
