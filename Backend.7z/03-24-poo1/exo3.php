<?php
/*
EXERCICE 3
- créer les classes Student, Session, etc. correspondantes au projet Toto avec toutes les propriétés en visibilité publique
EXERCICE-extra
- modifier le code source du projet pour qu'il utilise les objets
*/