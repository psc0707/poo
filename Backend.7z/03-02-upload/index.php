<?php

//echo '<pre>'.print_r($_POST,1).'</pre>';
// Pour l'upload des fichiers, les données seront dans $_FILES !!!!!
//echo '<pre>'.print_r($_FILES,1).'</pre>';

// Si formulaire soumis
if (!empty($_POST)) {
	// Si des fichiers ont été uploadés
	if (!empty($_FILES)) {
		// Je récupère les données sur le fichier uploadé (input name="fileForm")
		$currentFileUpload = $_FILES['fileForm'];

		// Je vérifie l'extension PDF
		if (substr($currentFileUpload['name'], -4) == '.pdf') {
			// Je vérifie le type MIMR
			if ($currentFileUpload['type'] == 'application/pdf') {
				// J'uploade le fichier (tmp -> files dir)
				if(move_uploaded_file($currentFileUpload['tmp_name'], './files/'.md5(time().getmypid().$currentFileUpload['size']).'.pdf')) {
					echo 'Upload réussi !!!!!!!!<br>';
					echo 'Size : '.$currentFileUpload['size'].'<br>';
					echo 'MIME Type : '.$currentFileUpload['type'].'<br>';
				}
				else {
					echo 'Bad news... upload failed<br>';
				}
			}
			else {
				echo 'Bad news... bad MIME type<br>';
			}
		}
		else {
			echo 'Bad news... bad extension<br>';
		}
	}
}

// Ma vue
require dirname(__FILE__).'/view/upload.html';