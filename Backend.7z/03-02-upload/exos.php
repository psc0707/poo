<?php

/* EXERCICE 1
------------------------
- modifier votre projet Toto pour pouvoir uploader une image pour chaque student (dans edit.php si possible, sinon add.php)
	* ne pas accepter les fichiers PHP dans cet upload
	* penser à bien renommer le fichier (par exemple avec l'id du student)
	* ajouter un champ dans table "student" qui contiendra le chemin relatif vers l'image du student

EXERCICE++
------------------------
- n'autoriser que certaines extensions à être uploader
	jpg, jpeg, gif, svg, png
- n'autoriser que des fichiers de 200 Ko maxmimum
	
EXERCICE-extra
------------------------
- faire un formulaire à part, où on upload un zip
- vérifier que c'est bien un zip
- décompresser le fichier
- supprimer tout fichier php qui aurait été décompressé
- afficher à l'écran les fichiers et dossiers décompressés
*/