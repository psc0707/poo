<html>
<head>
	<title>Ajax - formulaire</title>
	<style type="text/css">
	HTML, BODY { font-family: Helvetica, Arial, sans-serif; }
	</style>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
</head>
<body>
	<form action="" method="post" id="formAjax">
		<fieldset>
			<legend>Inscription</legend>
			Lastname<br>
			<input type="text" name="lnameToto" id="lname" value="" /><br>
			Firstname<br>
			<input type="text" name="fnameToto" id="fname" value="" /><br>
			Email<br>
			<input type="email" name="emailToto" id="email" value="" /><br>
			Password<br>
			<input type="password" name="passwordToto" id="password" value="" /><br>
			<input type="text" name="passwordToto2" id="password2" value="" placeholder="confirm" /><br>
			<br>
			<input type="submit" value="Valider"/>
		</fieldset>
	</form>

	<script type="text/javascript">
	// Lorsque la page est totalement chargée
	jQuery(document).ready(function() {
		//- intercepter la soumission du formulaire
		jQuery('#formAjax').submit(function(event) {
			// Je stoppe l'exécution normale (soumission du form)
			event.preventDefault();

			//- trouver une fonction simple permettant de récupérer toutes les données d'un formulaire en une ligne
			console.log( $( this ).serialize() );

			//- récupérer les données du formulaire en javascript pour les envoyer en POST dans la requête Ajax
			var formElement = jQuery('#formAjax');

			//- exécuter une requête ajax simple de type POST vers le fichier "ajax/signup.php"
			$.ajax({
				url : "ajax/signup.php",
				method: "POST",
				//- envoyer la donnée "toto" avec valeur 1, en ajax et en POST sur "ajax/signup.php"
				data: {
					toto: 1,
					//- récupérer les données du formulaire en javascript pour les envoyer en POST dans la requête Ajax
					lnameToto : formElement.find('input[name="lnameToto"]').val(),
					fnameToto : formElement.find('input[name="fnameToto"]').val(),
					emailToto : formElement.find('input[name="emailToto"]').val(),
					passwordToto : formElement.find('input[name="passwordToto"]').val(),
					passwordToto2 : formElement.find('input[name="passwordToto2"]').val()
				}
				//data: 'toto=1&tata=2' // Autre façon de faire (pas de ?)
			}).done(function(response) {
				// Je récupère la réponse renvoyée (si 1, form ok, si 0, y'a des erreurs)
				if (response == "1") {
					alert('Tout est ok');
				}
				else {
					alert('Bad news :(');
				}
			});
		});
	});
	</script>
</body>
</html>