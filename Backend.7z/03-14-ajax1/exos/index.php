<html>
<head>
	<title>Ajax</title>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
</head>
<body>
	<button id="btn">Piti bouton !</button>
	<pre>
		Contenu texte récupéré via ajax
		<textarea id="ajaxText" cols="60" rows="10"></textarea>
	</pre>
	<script type="text/javascript">
	// Lorsque la page est totalement chargée
	jQuery(document).ready(function() {
		//- exécuter chacune des actions précédentes, après un click sur un bouton
		jQuery('#btn').click(function() {
			//- exécuter une requête ajax simple vers le fichier "ajax/ajax.txt"
			jQuery.ajax({
				url : 'ajax/ajax.txt',
				method : 'GET'
			}).always(function() {
				//- lorsque la requête est terminée (avec ou sans erreur), afficher une "alert" : "ajax terminée"
				alert('ajax terminée');
			}).done(function(response) {
				//- lorsque la requête a réussie, afficher une alerte : "cool ça a marché"
				alert('cool ça a marché');
				//- lorsque la requête est réussie, afficher dans la console (console.log) le retour (la réponse)
				console.log(response);
				//- lorsque la requête est réussie, mettre le retour (la réponse) dans le textarea
				jQuery('#ajaxText').val(response);
			}).fail(function() {
				//- lorsque la requête est en erreur, afficher une alerte : "bad news... ERROR !"
				alert('bad news... ERROR !');
			});
		});
	});
	</script>
</body>
</html>