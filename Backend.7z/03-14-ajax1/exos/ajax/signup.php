<?php

//- tester l'envoi de la donnée grâce à print_r($_POST); dans le fichier "ajax/signup.php"

//print_r($_POST);

/*- si toutes les données sont correctes
	* ajax/signup.php affiche 1 => afficher une alerte "ok"
	* ajax/signup.php affiche 0 => afficher une alerte "données incorrectes"
- si des données sont incorrectes, retourner les erreurs
*/

if (!empty($_POST)) {
	$lastName = isset($_POST['lnameToto']) ? trim(strip_tags($_POST['lnameToto'])) : '';

	$formOk = true;

	// Je valide
	if (empty($lastName)) {
		$formOk = false;
	}
	else if (strlen($lastName) < 2) {
		$formOk = false;
	}
	// TODO faire toutes les vérifications

	if ($formOk) {
		echo 1;
	}
	else {
		echo 0;
	}
}
else {
	echo 0;
}