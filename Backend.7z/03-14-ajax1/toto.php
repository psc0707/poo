<?php

echo 'tototata';