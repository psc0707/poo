<pre><?php

// J'active l'autoload
spl_autoload_register();

// Imports
use \inc\VideoGame;

$dayOfTentacle = new VideoGame(
	'Day of Tentacule',
	'1993-06-25',
	'LucasArts',
	'Adventure',
	VideoGame::CONSOLE_PC,
    5
);
print_r($dayOfTentacle);

echo $dayOfTentacle->getTitle().'<br>';
$dayOfTentacle->displayDebutJeu();
$dayOfTentacle->displayFinJeu();

// EXO2 => json_encode
echo json_encode($dayOfTentacle, JSON_PRETTY_PRINT);

?></pre>