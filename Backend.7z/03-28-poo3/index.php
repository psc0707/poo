<pre><?php

// J'active l'autoload
spl_autoload_register();

use inc\Car; // import
use inc\Moteur; // import
use inc\Bike; // import
use inc\Moto; // import

// J'instancie ma voiture
$f40 = new Car(
	new Moteur(
        'Ferrari',
        'F120D',
        'Essence',
        352,
        8,
        2936
    ),
	'SFGh2465465DSFGHD',
	'DF 7896',
	'rouge',
	'Ferrari',
	'F40',
	2
);
print_r($f40);
$f40->paintInBlue();
$f40->setModel('GT40');
print_r($f40);

// Exo1
$velo = new Bike(
    'bleu',
    'Giant',    
    'G458',
    3,
    7
);
print_r($velo);
$velo->setNbSpeeds(4);
print_r($velo);
echo 'Steering : '.$velo->getSteeringName().'<br>';

// Exo1++
$sv650n = new Moto(
        'bleu',
        'Suzuki',
        'SV650n',
        new Moteur(
                'Suzuki',
                'BiCylindre',
                'Essence',
                50,
                2,
                650
            ),
        2,
        false,
        'roadster'
    );
print_r($sv650n);

// J'essaie d'instancier une classe abstraite
//$vehiculeTest = new inc\Vehicle('bleu', 'Toto', 'Titi', 455); // Génère une Fatal Error
//print_r($vehiculeTest);

// Appels aux méthodes commentAvancer();
$sv650n->commentAvancer();
echo '<br>';
$velo->commentAvancer();
echo '<br>';
$f40->commentAvancer();
echo '<br>';

// INTERFACE
$sv650n->immatriculer('SR-456-TR');
$sv650n->mettreEnCirculation();
print_r($sv650n);

// J'utilise une constante d'une interface
echo \inc\ImmatriculationInterface::CONSTANT_EXAMPLE.'<br>';

// PROPRIETES et METHODES STATIQUES
echo Car::$definition.'<br>';
Car::$definition = 'Toto';
echo Car::$definition.'<br>';

// J'appelle une méthode statique
echo 'steering 1 = '.\inc\Vehicle::getSteeringNameFromValue(1).'<br>';

// J'utilise le design pattern Factory
$sv650nBis = inc\Factory::loadMoto(
        'bleu',
        'Suzuki',
        'SV650n',
        new Moteur(
                'Suzuki',
                'BiCylindre',
                'Essence',
                50,
                2,
                650
            ),
        2,
        false,
        'roadster'
    );
print_r($sv650nBis);

?></pre>