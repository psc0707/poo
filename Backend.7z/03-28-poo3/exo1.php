<?php

/*
EXERCICE 1
-----------
- passer la classe Game en abstraite
- passer en abstrait les méthodes le nécessitant
- définir la méthode abstraite displayDebutJeu() dans la classe abstraite Jeu (cette méthode affiche 'Le jeuvidéo #titre commence maintenant !')
- définir la méthode abstraite displayFinJeu() dans la classe abstraite Jeu (cette méthode affiche 'Le jeuvidéo #titre est terminé.')
- écrire un script qui créé 1 instance de JeuVideo
	(par ex. NBA 2K16)
	* puis qui affiche le titre
	* puis qui appel les 2 méthodes abstraites définies
	
EXERCICE-extra
--------------
- faire de même avec les autres classes "enfant" de Game
- prendre connaissance des Design Patterns
	https://openclassrooms.com/courses/programmez-en-oriente-objet-en-php/les-design-patterns
*/