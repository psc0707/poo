<?php

namespace inc;

/**
 * Description of Vehicle
 *
 * @author Etudiant
 */
abstract class Vehicle {
	/** @var string */
	protected $color; // protected = private + tous les enfants
	/** @var string */
	protected $brand;
	/** @var string */
	protected $model;
	/** @var int */
    protected $nbWheels;
	/** @var int */
    protected $steering;
	/** @var string */
    protected $power; // motorisation
    
    public static $definition = 'Ce qui sert à transmettre, à transporter';
    
    // Propriété statique
    protected static $steeringValues = array(
        1 => 'Volant',
        2 => 'Guidon',
        3 => 'Manche',
    );
    
    const STEERING_WHEEL = 1; // volant
    const STEERING_HANDLE_BAR = 2; // guidon
    const STEERING_STICK = 3; // manche
    
    public function __construct($color='', $brand='', $model='', $nbWheels=0, $steering=0, $power='') {
        $this->color = $color;
        $this->brand = $brand;
        $this->model = $model;
        $this->nbWheels = $nbWheels;
        $this->steering = $steering;
        $this->power = $power;
    }
    
    /**
     * 
     * @return string
     */
    public function getSteeringName() {
        // J'appelle ma méthode statique
        return self::getSteeringNameFromValue($this->steering);
    }
    
    // Méthode static
    public static function getSteeringNameFromValue($steering) {
        if (array_key_exists($steering, self::$steeringValues)) {
            return self::$steeringValues[$steering];
        }
        return '-';
    }
    
    public abstract function commentAvancer();
    
    public function getColor() {
        return $this->color;
    }

    public function getBrand() {
        return $this->brand;
    }

    public function getModel() {
        return $this->model;
    }

    protected function setColor($color) {
        $this->color = $color;
    }

    public function setBrand($brand) {
        $this->brand = $brand;
    }

    public function setModel($model) {
        $this->model = $model;
    }
    
    public function getNbWheels() {
        return $this->nbWheels;
    }

    public function getSteering() {
        return $this->steering;
    }

    public function setNbWheels($nbWheels) {
        $this->nbWheels = $nbWheels;
    }

    public function setSteering($steering) {
        $this->steering = $steering;
    }

    public function getPower() {
        return $this->power;
    }

    public function setPower($power) {
        $this->power = $power;
    }


}
