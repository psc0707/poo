<?php

namespace inc;

/**
 * Description of Moto
 *
 * @author Etudiant
 */
class Moto extends Vehicle implements ImmatriculationInterface {
    /** @var Moteur */
    protected $moteur;
    /** @var int */
    protected $nbSeats;
    /** @var bool */
    protected $isWithSidecar;
    /** @var string */
    protected $type;
	/** @var string */
	protected $licencePlate;
	/** @var string */
	protected $date1ereMiseEnCirculation;
    
    public function __construct($color='', $brand='', $model='', $moteur=null, $nbSeats=1, $isWithSidecar=false, $type='', $licencePlate='', $date1ereMiseEnCirculation='') {
        // Appel constructeur parent
        parent::__construct($color, $brand, $model);
        
        // + affectations propriétés enfants
        $this->moteur = $moteur;
        $this->nbSeats = $nbSeats;
        $this->isWithSidecar = $isWithSidecar;
        $this->type = $type;
        $this->date1ereMiseEnCirculation = $date1ereMiseEnCirculation;
        $this->licencePlate = $licencePlate;
        
        // + affectations propriétés parents en dur (car ne change pas d'une moto à une autre)
        $this->nbWheels = 2;
        $this->power = 'moteur';
        $this->steering = Vehicle::STEERING_HANDLE_BAR;
    }
    
    public function commentAvancer() {
        echo 'Tourner la poignée';
    }

        /**
     * 
     * @return Moteur
     */
    public function getMoteur() {
        return $this->moteur;
    }

    /**
     * 
     * @return int
     */
    public function getNbSeats() {
        return $this->nbSeats;
    }

    /**
     * 
     * @return bool
     */
    public function getIsWithSidecar() {
        return $this->isWithSidecar;
    }

    /**
     * 
     * @return string
     */
    public function getType() {
        return $this->type;
    }

    /**
     * 
     * @param Moteur $moteur
     */
    public function setMoteur($moteur) {
        $this->moteur = $moteur;
    }

    /**
     * 
     * @param int $nbSeats
     */
    public function setNbSeats($nbSeats) {
        $this->nbSeats = $nbSeats;
    }

    /**
     * 
     * @param bool $isWithSidecar
     */
    public function setIsWithSidecar($isWithSidecar) {
        $this->isWithSidecar = $isWithSidecar;
    }

    /**
     * 
     * @param string $type
     */
    public function setType($type) {
        $this->type = $type;
    }
    
    public function getLicencePlate() {
        return $this->licencePlate;
    }

    public function getDate1ereMiseEnCirculation() {
        return $this->date1ereMiseEnCirculation;
    }

    public function setLicencePlate($licencePlate) {
        $this->licencePlate = $licencePlate;
    }

    public function setDate1ereMiseEnCirculation($date1ereMiseEnCirculation) {
        $this->date1ereMiseEnCirculation = $date1ereMiseEnCirculation;
    }

        
    public function immatriculer($licensePlate) {
        $this->licencePlate = $licensePlate;
    }

    public function mettreEnCirculation() {
        $this->date1ereMiseEnCirculation = date('Y-m-d');
    }

}
