<?php

namespace inc;

// Je définis ma classe Voiture et j'implémente l'interface
class Car extends Vehicle implements ImmatriculationInterface {
	/** @var Moteur */
	public $moteur;
	/** @var string */
	public $vin;
	/** @var string */
	public $licencePlate;
	/** @var int */
	public $nbDoors;
	/** @var string */
	public $date1ereMiseEnCirculation;
    
    public static $definition = 'Véhicule motorisé avec 4 roues';

	// Je crée mon constructeur
	public function __construct($moteur=null, $vin='', $licencePlate='', $color='', $brand='', $model='', $nbPortes=0, $date1ereMiseEnCirculation='') {

		$this->moteur = $moteur;
		$this->vin = $vin;
		$this->licencePlate = $licencePlate;
		$this->date1ereMiseEnCirculation = $date1ereMiseEnCirculation;
		// Je modifie la propriété nbDoors de l'objet courant
		$this->nbDoors = $nbPortes;
        
		/* Plus besoin, car dans le constructeur surchargé
        $this->color = $color;
		$this->brand = $brand;
		$this->model = $model;*/
        
        // J'appelle le constructeur du parent
        // (j'ai surchargé/override le constructeur)
        parent::__construct($color, $brand, $model);
        
        // Je définis les valeurs pour les propriétés héritées
        $this->nbWheels = 4;
        $this->steering = Vehicle::STEERING_WHEEL;
        $this->power = 'moteur';
    }

	// On déstructeur existe aussi, il est automatiquement appelé à la suppression de l'objet
	public function __destruct() {
		echo 'Car détruit<br>';
	}

	// Je définis une méthode "paint" à ma classe
	// Elle modifie la propriété color
	public function paint($newColor) {
		if (strlen($newColor) >= 3) {
			$this->color = $newColor;
		}
	}

	public function paintInBlue() {
		$this->setColor('blue');
	}

	public function paintInPink() {
		$this->setColor('pink');
	}

	// Setter avec vérification du type de la donnée
	public function setMoteur($moteur) {
		if (is_a($moteur, 'Moteur')) {
			$this->moteur = $moteur;
		}
	}
    
    // Override de setModel
    public function setModel($model) {
        $model .= 'Toto';
        // Appelle la méthode setModel de la classe parent
        parent::setModel($model);
    }
 
    public function commentAvancer() {
        echo 'Appuyer sur l\'accélérateur';
    }
    
    public function immatriculer($licensePlate) {
        $this->licencePlate = $licensePlate;
    }

    public function mettreEnCirculation() {
        $this->date1ereMiseEnCirculation = date('Y-m-d');
    }
}