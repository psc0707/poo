<?php

namespace inc;

/**
 * Description of MotoFactory
 *
 * @author Etudiant
 */
class Factory {
    public static function loadMoto($color='', $brand='', $model='', $moteur=null, $nbSeats=1, $isWithSidecar=false, $type='', $licencePlate='', $date1ereMiseEnCirculation='') {
        $object = new Moto($color, $brand, $model, $moteur, $nbSeats, $isWithSidecar, $type, $licencePlate, $date1ereMiseEnCirculation);
        return $object;
    }
}
