<?php

namespace inc;

/**
 * Description of Bike
 *
 * @author Etudiant
 */
class Bike extends Vehicle {
    /** @var int */
    protected $nbGears;
    /** @var int */
    protected $nbSpeeds;
    
    public function __construct($color='', $brand='', $model='', $nbGears=0, $nbSpeeds=0) {
        // Appel constructeur parent
        parent::__construct($color, $brand, $model);
        
        // + affectations propriétés enfants
        $this->nbGears = $nbGears;
        $this->nbSpeeds = $nbSpeeds;
        
        // + affectations propriétés parents en dur (car ne change pas d'un vélo à un autre)
        $this->nbWheels = 2;
        $this->steering = Vehicle::STEERING_HANDLE_BAR;
        $this->power = 'pedalier';
    }
    
    public function commentAvancer() {
        echo 'Pédaler';
    }

    
    public function getNbGears() {
        return $this->nbGears;
    }

    public function getNbSpeeds() {
        return $this->nbSpeeds;
    }

    public function setNbGears($nbGears) {
        $this->nbGears = $nbGears;
    }

    public function setNbSpeeds($nbSpeeds) {
        $this->nbSpeeds = $nbSpeeds;
    }
}
