<?php

namespace inc;

/**
 *
 * @author Etudiant
 */
interface ImmatriculationInterface {
    const CONSTANT_EXAMPLE = 2;
    
    // Modifie la date de 1ère mise en circulation
    public function mettreEnCirculation();
    
    // Définit la licensePlate
    public function immatriculer($licensePlate);
}
