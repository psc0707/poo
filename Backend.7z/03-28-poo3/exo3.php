<?php

/*
EXERCICE 3
- ajouter la propriété "ageMinimum" à la classe Jeu
- définir les propriétés statiques correspondant
	à l'age maximum pour le public bébé,
	à l'age maximum pour le public enfant,
	à l'age maximum pour le public adolescent,
	à l'age maximum pour le public adulte,
	à l'age maximum pour le public "personnes d'un âge avancé"
- ajouter la méthode "publicVise" à Jeu
	qui renverra le nom du ou des publics visé
	en se basant sur l'âge minimum
EXERCICE-extra
- continuer sur Design Patterns, mais surtout bien comprendre "Singleton"
	https://openclassrooms.com/courses/programmez-en-oriente-objet-en-php/les-design-patterns

*/