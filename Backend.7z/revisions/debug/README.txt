J'ai écrit du code pour afficher la liste des équipes NBA à partir de la base de données. Sur ma machine, la base s'appelle "nbateams".

Mais, je me suis dépêché à la faire, et il y a beaucoup d'erreur et de bug dedans. Je n'ai pas le temps de les corriger. Il faudrait donc le faire à ma place.

Au final, la liste des équipes doit s'effectuer complètement (30 équipes) et la recherche textuelle et le tri doivent correctement fonctionner.

Un fichier sql est fourni pour créer les tables avec leurs données dans votre DB.

Bon courage :)