<?php
$pdo = new PDO('mysql=host:localhost;dbname:nba-teams;charset:utf8', 'totowf3', 'root');