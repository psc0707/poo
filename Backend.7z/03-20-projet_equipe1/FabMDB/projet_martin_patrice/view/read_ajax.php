<div class="row">
	<div class="col-md-6">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Student List</h3>
			</div>
			<div class="panel-body">
		    







			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Student Details</h3>
			</div>
			<div class="panel-body">
		    	<ul>
		    		<li>Nom : </li>
		    		<li>Prénom : </li>
		    		<li>Email : </li>
		    		<li>Age : </li>
		    		<li>Ville : </li>
		    		<li>Pays : </li>
		    	</ul>




			</div>
		</div>
	</div>
</div>

















