-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2017 at 05:05 PM
-- Server version: 5.5.50-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `martinst_sql0`
--

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE IF NOT EXISTS `movies` (
  `mov_id` int(11) NOT NULL AUTO_INCREMENT,
  `mov_title` varchar(45) NOT NULL,
  `mov_released` date NOT NULL,
  `mov_director` varchar(45) NOT NULL,
  `mov_runtime` varchar(45) NOT NULL,
  `mov_actors` mediumtext NOT NULL,
  `mov_synopsis` longtext NOT NULL,
  `mov_language` varchar(45) NOT NULL,
  `mov_poster` mediumtext NOT NULL,
  `mov_rating` float DEFAULT NULL,
  `mov_support` enum('USB','Youtube','NAS','Local') NOT NULL,
  `mov_link` varchar(240) DEFAULT NULL,
  `categories_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`mov_id`),
  KEY `fk_movies_categories_idx` (`categories_cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`mov_id`, `mov_title`, `mov_released`, `mov_director`, `mov_runtime`, `mov_actors`, `mov_synopsis`, `mov_language`, `mov_poster`, `mov_rating`, `mov_support`, `mov_link`, `categories_cat_id`) VALUES
(2, 'Forrest Gump', '1994-07-06', 'Robert Zemeckis', '142', 'Tom Hanks, Rebecca Williams, Sally Field, Michael Conner Humphreys', 'Forrest Gump, while not intelligent, has accidentally been present at many historic moments, but his true love, Jenny Curran, eludes him.', 'English', 'https://images-na.ssl-images-amazon.com/images/M/MV5BYThjM2MwZGMtMzg3Ny00NGRkLWE4M2EtYTBiNWMzOTY0YTI4XkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg', 8.8, 'Local', NULL, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `movies`
--
ALTER TABLE `movies`
  ADD CONSTRAINT `fk_movies_categories` FOREIGN KEY (`categories_cat_id`) REFERENCES `categories` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
