// --------------------
//     EXERCICE 1
// --------------------

- récupérer maps.html
- ajouter le code HTML/Javascript pour récupérer les coordonnées GPS de l'adresse du formulaire

// --------------------
//    EXERCICE ++
// --------------------

- Afficher la map GoogleMaps avec un marker correspondant à l'adresse