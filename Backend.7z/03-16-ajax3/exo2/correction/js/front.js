$(document).ready(function() {
	// Je cache les panel "signin" et "signup"
	$('.panel-room').hide();

	// Intrerception de la soumission du signup
	$('#form-signup').submit(function(e) {
		e.preventDefault();

		if ($('#confirm').val() == $('#password2').val()) {
			$.ajax({
				url: 'http://wf3.progweb.fr/chat-api/user/signup/',
				dataType: 'json',
				type: 'post',
				cache: false,
				data: {
					username: $('#username2').val(),
					password: $('#password2').val()
				}
			}).done(function(jsonData) {
				if (jsonData.code == 1) {
					bootstrapAlert('Signup', 'inscription réussie');
				}
				else {
					bootstrapAlert('Signup', jsonData.error);
				}
				console.log(jsonData);
			});
		}
		else {
			bootstrapAlert('Signup', 'Mots de passe différents');
		}
	});

	// Intrerception de la soumission du signin
	$('#form-signin').submit(function(e) {
		e.preventDefault();

		$.ajax({
			url: 'http://wf3.progweb.fr/chat-api/user/signin/',
			dataType: 'json',
			type: 'post',
			cache: false,
			data: {
				username: $('#username').val(),
				password: $('#password').val()
			}
		}).done(function(jsonData) {
			console.log(jsonData);
			if (jsonData.id > 0) {
				bootstrapAlert('Signin', 'connexion réussie');

				// J'enregistre l'id du user pour les autres forms
				currentUserId = jsonData.id;

				// Si le user est connecté
				if (currentUserId > 0) {
					// Alors je cache les panels "signin" & "signup"
					$('.panel-sign').hide();
					// Et j'affiche le panel des messages
					$('.panel-room').show();
					// Je charge les rooms
					loadRooms();
					// Je charge les messages
					loadMessages();
				}
			}
			else {
				bootstrapAlert('Signin', jsonData.error);
			}
		});
	});

	// Intrerception de la soumission de l'ajout de message
	$('#form-message').submit(function(e) {
		e.preventDefault();

		// Ajout d'un message uniquement si le user est connecté
		if (currentUserId > 0) {
			$.ajax({
				url: 'http://wf3.progweb.fr/chat-api/message/add/',
				dataType: 'json',
				type: 'post',
				cache: false,
				data: {
					message: $('#message').val(),
					user: currentUserId,
					room: $('#roomSelect').val()
				}
			}).done(function(jsonData) {
				if (jsonData.code == 1) {
					bootstrapAlert('Room', 'message envoyé');
				}
				else {
					bootstrapAlert('Room', jsonData.error);
				}
				console.log(jsonData);
				// Je vide le champ input pour réécrire un nouveau message
				$('#message').val('');
			});
		}
		else {
			bootstrapAlert('Room', 'User non connecté');
		}
	});

	// Lors d'un changement sur le menu déroulant des "rooms"
	$('#roomSelect').change(function(e) {
		e.preventDefault();

		// Chargement des messages uniquement si le user est connecté
		if (currentUserId > 0) {
			loadMessages();
		}
		else {
			bootstrapAlert('Room', 'User non connecté');
		}
	});
});

// J'initialise la variable contenant l'id du user connecté (0 si non connecté)
var currentUserId = 0;

// Fonction chargeant tous les messages pour la room sélectionnée
function loadMessages() {
	if (currentUserId > 0 && $('#roomSelect').val() > 0) {
		$.ajax({
			url: 'http://wf3.progweb.fr/chat-api/message/get/',
			dataType: 'json',
			type: 'get',
			cache: false,
			data: {
				user: currentUserId,
				room: $('#roomSelect').val()
			}
		}).done(function(jsonData) {
			$('#chatContent tbody').html('');
			if (jsonData.code == 0) {
				
			}
			else {// Je vide le body du table
				// Je parcours les résultats (les messages)
				$.each(jsonData, function(index, value) {
					// Pour remplir le body du table
					$('#chatContent tbody').append('<tr><td>'+value.username+'</td><td>'+value.createdAt+'</td><td>'+value.message+'</td></tr>')
				});
			}
			// Permet de charger indéfiniment les messages, toutes les 4 secondes
			window.setTimeout(loadMessages, 4000);
		});
	}
}

// Fonction permettant de charger les rooms dans le menu déroulant
function loadRooms() {
	$.ajax({
		url: 'http://wf3.progweb.fr/chat-api/room/get/',
		cache: false,
		dataType: 'jsonp'
	}).done(function(jsonData) {
		// Je vide le select
		$('#roomSelect').html('<option value="0">choose</option>');
		// Je parcours mon tableau (comme foreach)
		$.each(jsonData, function(index, toto) {
			// Pour remplir le select avec les rooms récupérées par Ajax
			$('#roomSelect').append('<option value="'+toto.id+'">'+toto.roomName+'</option>');
		});
	});
}

function bootstrapAlert(title, txt) {
	$('#modalTitle').html(title);
	$('#modalText').html(txt);
	$('#myModal').modal();
}