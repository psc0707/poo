<?php

require 'inc/config.php';

$studentList = array();

/*$sql = '
	SELECT *
	FROM student
	INNER JOIN city ON city.cit_id = student.city_cit_id
	INNER JOIN country ON country.cou_id = city.country_cou_id
	ORDER BY stu_firstname ASC, stu_lastname ASC
';*/
$sql = '
	SELECT ses_id, ses_number, loc_name
	FROM session
	INNER JOIN location ON location.loc_id = session.location_loc_id
';
$stmt = $pdo->query($sql);

if ($stmt === false) {
	print_r($pdo->errorInfo());
}
else {
	$sessionList = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$btnColors = array(
	'primary',
	'success',
	'danger',
	'warning',
	'info',
	'default'
);

require 'view/home.php';