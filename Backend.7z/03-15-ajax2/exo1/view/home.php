<html>
<head>
	<title>Students Ajax</title>
	<meta charset="utf-8">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<style type="text/css">
	a.btn {
		margin: 5px;
	}
	</style>
</head>
<body>


<div class="container">
	<br>
	<div class="col-sm-6 col-md-6">
		<br>
		<div class="panel panel-primary">
			<!-- Default panel contents -->
			<div class="panel-heading">Students list</div>
			<div class="panel-body">
				<select id="sessionSelect">
					<option value="0">Choose :</option>
					<?php foreach ($sessionList as $currentSession) : ?> 
						<option value="<?= $currentSession['ses_id'] ?>"><?= $currentSession['loc_name'] ?> #<?= $currentSession['ses_number'] ?></option>
					<?php endforeach; ?>
				</select>

				<div id="btns"></div>
				
				<?php /*foreach ($studentList as $currentStudent) : ?>
					<a href="javascript:loadStudent(<?= $currentStudent['stu_id'] ?>)" class="btn btn-sm btn-<?= $btnColors[array_rand($btnColors)] ?>" data-studentId="<?= $currentStudent['stu_id'] ?>"><?= $currentStudent['stu_firstname'] ?> <?= $currentStudent['stu_lastname'] ?></a>
				<?php endforeach;*/ ?>
			</div>
		</div>
	</div>
	<div class="col-sm-6 col-md-6">
		<br>
		<div class="panel panel-primary">
			<!-- Default panel contents -->
			<div class="panel-heading">Student</div>
			<div class="panel-body">
				<table class="table">
					<tbody>
					<tr>
						<td>Nom</td>
						<td id="lname"></td>
					</tr>
					<tr>
						<td>Prénom</td>
						<td id="fname"></td>
					</tr>
					<tr>
						<td>Email</td>
						<td id="email"></td>
					</tr>
					<tr>
						<td>Age</td>
						<td id="age"></td>
					</tr>
					<tr>
						<td>Ville</td>
						<td id="city"></td>
					</tr>
					<tr>
						<td>Pays</td>
						<td id="country"></td>
					</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<footer>
		<div class="panel panel-primary">
			<div class="panel-body text-center">&copy; proGweb - Webforce3 - Numericall</div>
		</div>
	</footer>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<script type="text/javascript">
	function loadStudent(stuId) {
		// J'ajoute un hash dans l'url (segment/fragment)
		location.hash = stuId;

		// Appel AJAX en post sur ajax/student.php
		$.ajax({
			type: 'POST',
			url: 'ajax/student.php',
			dataType: 'json',
			data: {
				'studentId' : stuId
			}
			//data: 'studentId='+stuId
		}).done(function(response) {
			if (response.code == 1) {
				//console.log(response);
				$('#fname').html(response.data.stu_firstname);
				$('#lname').html(response.data.stu_lastname);
				$('#email').html(response.data.stu_email);
				$('#age').html(response.data.age);
				$('#city').html(response.data.cit_name);
				$('#country').html(response.data.cou_name);
			}
			else {
				alert('Ajax error');
			}
		});
	}
	var btnColors = ['primary','success','danger','warning','info','default','primary','success','danger','warning','info','default','primary','success','danger','warning','info','default','primary','success','danger','warning','info','default'];
	function changeColors() {
		$('.btn').each(function() {
			$(this).attr('class', 'btn btn-sm btn-'+btnColors[Math.floor(Math.random()*btnColors.length)]);
		});
		window.setTimeout(changeColors, 2000);
	}
	function loadStudentsForSessionId(sessionId) {
		// Appel AJAX en post sur ajax/student.php
		$.ajax({
			type: 'POST',
			url: 'ajax/session.php',
			dataType: 'json',
			data: {
				'sessionId' : sessionId
			}
			//data: 'studentId='+stuId
		}).done(function(response) {
			if (response.code == 1) {
				//console.log(response);
				$('#btns').html("");
				$.each(response.data, function(index, value) {
					var htmlContent = '<a href="javascript:loadStudent('+value.stu_id+')" class="btn btn-sm btn-default">'+value.stu_firstname+' '+value.stu_lastname+'</a>';
					$('#btns').append(htmlContent);
				});
			}
			else {
				alert('Ajax error');
			}
		});
	}

	$(document).ready(function() {
		// Je vérifie la présence d'un #
		if (location.hash) {
			// Alors je récupère la valeur
			var hashId = location.hash.replace('#', '');
			// Je charge les données du student
			loadStudent(hashId);
		}

		// J'intercepte l'évenement "dropdown sélectionné"
		$('#sessionSelect').change(function(event) {
			event.preventDefault();

			// J'appelle la fonction qui charge les students (boutons)
			loadStudentsForSessionId($(this).val());
		});

		window.setTimeout(changeColors, 2000);
	});
</script>
</body>
</html>