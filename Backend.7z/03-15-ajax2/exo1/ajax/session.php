<?php

header("Content-type:application/json");

require '../inc/config.php';

$sessionId = isset($_POST['sessionId']) ? intval(trim($_POST['sessionId'])) : 0;

$sql = '
	SELECT stu_id, stu_lastname, stu_firstname
	FROM student
	WHERE session_ses_id = :id
';
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $sessionId, PDO::PARAM_INT);

if ($stmt->execute() === false) {
	print_r($stmt->errorInfo());
}
else {
	$studentList = $stmt->fetchAll(PDO::FETCH_ASSOC);

	// Je structure mon tableau à encoder en JSON
	$returnedJsonArray = array(
		'code' => 1,
		'errorList' => array(),
		'data' => $studentList
	);
	// J'affiche le json et j'arrete le script
	die(json_encode($returnedJsonArray, JSON_PRETTY_PRINT));
}

// Je structure mon tableau à encoder en JSON
$returnedJsonArray = array(
	'code' => 0,
	'errorList' => array(
		'Execution error'
	),
	'data' => array()
);
// J'affiche le json et j'arrete le script
die(json_encode($returnedJsonArray));