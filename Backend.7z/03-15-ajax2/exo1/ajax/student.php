<?php

header("Content-type:application/json");

require '../inc/config.php';

$studentId = isset($_POST['studentId']) ? intval(trim($_POST['studentId'])) : 0;

// J'écris ma requête
$sql = '
	SELECT stu_lastname, stu_firstname, stu_email, cit_name, cou_name, stu_birthdate
	FROM student
	LEFT JOIN city ON city.cit_id = student.city_cit_id
	LEFT JOIN country ON country.cou_id = city.country_cou_id
	WHERE stu_id = :id
';
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $studentId, PDO::PARAM_INT);

// J'exécute ma requête préparée
if ($stmt->execute() === false) {
	// J'affiche les erreurs
	print_r($stmt->errorInfo());
}
else {
	// La requête est ok
	$studentInfos = $stmt->fetch(PDO::FETCH_ASSOC);

	// J'ajoute l'age
	$studentInfos['age'] = getAgeFromTimestamp(strtotime($studentInfos['stu_birthdate']));

	// Je structure mon tableau à encoder en JSON
	$returnedJsonArray = array(
		'code' => 1,
		'errorList' => array(),
		'data' => $studentInfos
	);
	// J'affiche le json et j'arrete le script
	die(json_encode($returnedJsonArray, JSON_PRETTY_PRINT));
}

// Je structure mon tableau à encoder en JSON
$returnedJsonArray = array(
	'code' => 0,
	'errorList' => array(
		'Execution error'
	),
	'data' => array()
);
// J'affiche le json et j'arrete le script
die(json_encode($returnedJsonArray));