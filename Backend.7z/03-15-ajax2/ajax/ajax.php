<?php

header("Content-type:application/json");

// JE crée un tableau associatif simple
$monTableauAssociatif = array(
	'code' => 1,
	'errorList' => array(),
	'data' => array(
		'nom' => 'CORDIER',
		'prenom' => 'Benjamin',
		'email' => 'ben@progweb.fr'
	)
);

// J'affiche la représentation JSON de ce tableau
$json = json_encode($monTableauAssociatif, JSON_PRETTY_PRINT);
echo $json.PHP_EOL;

// Je décode le json
$obj = json_decode($json);
//print_r($obj);
$arr = json_decode($json, true);
//print_r($arr);